/*CITIZEN TABLE:*/
CREATE TABLE citizen (
    nationalID VARCHAR(16) PRIMARY KEY NOT NULL,
    firstName VARCHAR(45),
    lastName VARCHAR(45),
    sex VARCHAR(45),
    dateOfBirth Date 
); 

/*DISTRICT TABLE*/
CREATE TABLE district (
    id int PRIMARY KEY NOT NULL,
    name VARCHAR(45)
); 

/*SAVING DISTRICTS*/
INSERT INTO districts VALUES (1, 'Gasabo');
INSERT INTO districts VALUES (2, 'Kicukiro');
INSERT INTO districts VALUES (3, 'Nyarugenge');
INSERT INTO districts VALUES (4, 'Nyamagabe');
INSERT INTO districts VALUES (5, 'Karongi');
